

def hello():
    return "hello"